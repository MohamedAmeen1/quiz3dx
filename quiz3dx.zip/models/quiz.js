const mongoose = require("mongoose");
const Joi =require('joi')
const question= new mongoose.Schema({
    title:{
        type:String
    },
    answers:[
        String
    ],
    correct:{
        type:Number
    }
})
const quizSchema=new mongoose.Schema({
    name:{
        type: String,
        required: true,
        required: 'name is required'
    },
    status:{
        type:Number,
        default:0
    },
    questions:[
        question
    ],
    owner:{
        type:mongoose.SchemaTypes.ObjectId ,ref:'user'
    }
})
module.exports.quiz =mongoose.model("quiz", quizSchema)