var bcrypt = require('bcryptjs');
var SALT_WORK_FACTOR = 10;
saltRounds=10;
require('dotenv').config();


module.exports = {
    encrypt: async function (plain_text){
        let h=0;
        await bcrypt
        .genSalt(saltRounds)
        .then(salt => {
          return bcrypt.hash(plain_text, salt);
        })
        .then(hash => {
            h=hash
            return
        })
        .catch(err => console.error(err.message));
        return h
    },
  };