const express = require('express');
var helper =require('../helper')
var router =express.Router();
const mongoose = require('mongoose');
const jwt=require('jsonwebtoken')
var bcrypt = require('bcryptjs');
require('dotenv').config()
const {user,validate}=require('../models/user')

router.get('/signup',(req,res)=>{
    res.render('user/signup')
})
router.get('/signin',(req,res)=>{
    res.render('user/signin')
})
router.get('/wellcome',(req,res)=>{
    res.render('user/wellcome')
})
router.post('/signup',async (req,res)=>{
    const {error}=validate(req.body)
    if(error) 
   {
       req.body.Error=error.details[0].message
        return res.render('user/signup',{
        user: req.body
    })}
    let new_user=new user()
    new_user.name=req.body.name
    new_user.email=req.body.email
    let cipher_pass=await helper.encrypt(req.body.password)
    new_user.password=cipher_pass
    new_user.save((err,user)=>{
        if(err){
            if(err.code==11000)
            req.body.Error="This Email Is Taken"
            else
            req.body.Error="ERROR IN SERVER You May try our App later"
        res.render('user/signup',{
            user: req.body
        })}
        else
        {
            let token=jwt.sign({id:user._id}, process.env.user_private_key)
            res.cookie('quizUserToken', token);
            res.redirect('wellcome')
        }
    })
    console.log(new_user)
   
})
router.post('/signin',(req,res)=>{
    user.findOne({'email':req.body.email},async (err, user)=>{
        if (err || user==null) {
             req.body.Error="Wrong Email"
             return  res.render('user/signin',{
                user: req.body
            })
        }
        else {
             const valid = await bcrypt.compare(req.body.password,user.password); 
              if(!valid) {
                req.body.Error="Wrong Password"
                return  res.render('user/signin',{
                   user: req.body
               })
              }
              let token=jwt.sign({id:user._id}, process.env.user_private_key)
              res.cookie('quizUserToken', token);
              res.redirect('wellcome')
                
        }
    })
    
})
function handelError(err,body){

}
module.exports=router